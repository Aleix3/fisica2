Thanks for downloading my pack! I hope you enjoy using it!

Follow me / Support my work <3
-------------------------------
https://soundcloud.com/emmaoyama
https://emmaoyama.bandcamp.com
https://twitter.com/emma_o_yama
https://instagram.com/emma_o_yama
https://patreon.com/weirdoonthebus